===================================
Alcatel-Lucent Enterprise Aos Collection Release Notes
===================================

.. contents:: Topics


v1.0.0
======

New Plugins
-----------

Cliconf
~~~~~~~

- aos - Use aos cliconf to run command on Alcatel-Lucent Enterprise AOS platform

New Modules
-----------

- aos_config - Manage Alcatel-Lucent Enterprise AOS configuration sections
